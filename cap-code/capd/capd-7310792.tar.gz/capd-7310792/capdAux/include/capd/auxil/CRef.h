/// @addtogroup auxil
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file CRef.h
///
/// @author Marian Mrozek
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2006 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.wsb-nlu.edu.pl/ for details.

#ifndef CAPD_AUXIL_CREF_H
#define CAPD_AUXIL_CREF_H

#include <stdexcept>
#include <iostream>

template<typename T>
class CRef;

template<typename T>
class CRef{
  private:
    T* ptr;
    int* cnt;
    void remove() {
      if (cnt && (--*cnt == 0)){
        delete cnt;
        if(ptr) delete ptr;

	cnt = 0;
	ptr = 0;
      }
    }
  public:
    explicit CRef():ptr(0),cnt(0){}
    explicit CRef(T* p):ptr(p),cnt(new int(1)){}
    CRef(const CRef<T>& p)throw():ptr(p.ptr),cnt(p.cnt){
      if(cnt) ++*cnt;
    }
    ~CRef()throw(){
      remove();
    }

  void release()
  {
    ptr = 0;
    remove();
  }

    CRef<T>& operator=(const CRef<T>& p)throw(){
      if(this != &p){
        remove();
        ptr=p.ptr;
        cnt = p.cnt;
        if(cnt) ++*cnt;
      }
      return *this;
    }
    T& operator()() const{
      if(ptr) return *ptr;
      throw std::domain_error("CRef::operator() : null reference");
    }
    T& operator*() const {
      if(ptr) return *ptr;
      throw std::domain_error("CRef::operator* : null reference");
    }
    int count() const {
      if(cnt) return *cnt;
      throw std::domain_error("CRef::count : null reference");
    }
    bool isNull(){
      return !ptr;
    }
    friend std::ostream& operator<<(std::ostream& out,const CRef<T>& A_CRef){
      out << "CRef pointing at address " << std::hex << A_CRef.ptr;
      out << " with count=" << std::dec << *A_CRef.cnt << " ";
      return out;
    }
};
#endif // CAPD_AUXIL_CREF_H

/// @}

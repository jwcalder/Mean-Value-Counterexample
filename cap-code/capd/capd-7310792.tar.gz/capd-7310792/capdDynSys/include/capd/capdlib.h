//////////////////////////////////////////////////////////////////////////////
//   Package:          CAPD

/////////////////////////////////////////////////////////////////////////////
//
/// @file capd/capdlib.h
///
/// @author Tomasz Kapela   @date 2010-01-23
//
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) Tomasz Kapela 2010
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef CAPD_CAPDLIB_H
#define CAPD_CAPDLIB_H

// capdAlg
#include "capd/intervals/lib.h"
#include "capd/vectalg/lib.h"
#include "capd/fields/lib.h"
// capdDynSys
#include "capd/map/lib.h"
#include "capd/diffAlgebra/lib.h"
#include "capd/dynset/lib.h"
#include "capd/dynsys/lib.h"
#include "capd/poincare/lib.h"
#include "capd/alglib/lib.h"
#include "capd/diffIncl/lib.h"

#include "capd/matrixAlgorithms/lib.h"
#undef CAPD_DEFAULT_DIMENSION
#endif // CAPD_CAPDLIB_H
